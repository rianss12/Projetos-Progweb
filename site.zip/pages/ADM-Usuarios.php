<!-- HTML 4 -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- HTML5 -->
<meta charset="utf-8"/>

<?php include '../resource/scripts/connect.php';?>

<!DOCTYPE html>
<html>
    
    <head>
        <title> ADM: Usuários</title>

        <link rel="stylesheet" href="../resource/css/styles.css">
    </head>

    <body>
        
        <nav id="menu-h">
            <ul>
                <li><a href="../index.php">Audopt</a></li>
                <li><a href="./ADM-Usuarios.php">Usuarios</a></li>
                <li><a href="./ADM-Cachorros.php">Cachorros</a></li>
            </ul>
        </nav>

        <br>
        <h3><mark>Usuários cadastrados</mark></h3>

        <br><br>

        <table width="40%" border="1">
            <tr>
                <th>Id</th>
                <th>Username</th>
                <th>Ação</th>
            </tr>
            <tr>
                <?php  
                    $results = $mysqli_connection->query("SELECT * FROM User");

                    while($row = $results->fetch_assoc()){
                        $delete = "../resource/scripts/deletar-usuario.php?userID=" .$row["id"];
                        echo "<tr>";
                        echo ' <td>'.$row["id"].'</td>';
                        echo ' <td>'.$row["username"].'</td>';
                        echo " <td><a href='{$delete}' >Deletar</a></td>";
                        echo "</tr>";
                    }
                ?>
            </tr>
        </table>

        <br>
        <h3 sstyle="margin:auto;"><mark>Cadastrar Usuário</mark></h3>

        <table width="40%" height="50%" style="margin:auto;" >
            <tr>
                <td style="font-size: larger; top: 5%;">
                    <form method="POST" action="../resource/scripts/cadastrar-usuario.php">
                       
                        <label for="flogin">Login</label><br>
                        <input type="text" id="flogin" name="flogin" value="" required><br>

                        <label for="fpwd">Senha</label><br>
                        <input type="password" id="fpwd" name="fpwd" value="" required><br>

                        <label for="fpwd2">Confirme a senha</label><br>
                        <input type="password" id="fpwd2" name="fpwd2" value="" required><br>
                       
                        <input type="reset">   <input type="submit" value="Submit">
                     
                    </form> 
                </td>
        </table>

        <footer>
            Site desenvolvido por Victor Santos
        </footer>

    </body>
</html>