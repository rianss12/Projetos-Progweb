<!-- HTML 4 -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- HTML5 -->
<meta charset="utf-8"/>

<?php include '../resource/scripts/connect.php';?>

<!DOCTYPE html>
<html>
    
    <head>
        <title> ADM: Cachorros</title>

        <link rel="stylesheet" href="../resource/css/styles.css">
        <style>
            img{
                width: 100px;
            height: 120px;
            }
            
        </style>
    </head>

    <body>
        
        <nav id="menu-h">
            <ul>
                <li><a href="../index.php">Audopt</a></li>
                <li><a href="./ADM-Usuarios.php">Usuários</a></li>
                <li><a href="./ADM-Cachorros.php">Cachorros</a></li>
            </ul>
        </nav>

        <br>
        <h3><mark>Cachorros cadastrados</mark></h3>

        <br><br>

        <table width="40%" border="1">
            <tr>
                <th>Id</th>
                <th>Foto</th>
                <th>Nome</th>
                <th>Idade</th>
                <th>Raça</th>
                <th>Sexo</th>
                <th>Cor</th>
                <th>Descrição</th>
            </tr>
            <tr>
                <?php  
                    $results = $mysqli_connection->query("SELECT * FROM Cachorro");

                    while($row = $results->fetch_assoc()){
                        $delete = "../resource/scripts/deletar-cachorro.php?dogID=" .$row["id"];
                        echo "<tr>";
                        echo ' <td>'.$row["id"].'</td>';
                        echo " <td>  <img src=\"".$row["foto_url"]."\" alt=\"Avatar\"></td>";
                        echo ' <td>'.$row["nome"].'</td>';
                        echo ' <td>'.$row["idade"].'</td>';
                        echo ' <td>'.$row["raca"].'</td>';
                        echo ' <td>'.$row["sexo"].'</td>';
                        echo ' <td>'.$row["cor"].'</td>';
                        echo ' <td>'.$row["descricao"].'</td>';
                        echo " <td><a href='{$delete}' >Deletar</a></td>";
                        echo "</tr>";
                    }
                ?>
            </tr>
        </table>

        <br>
        <h3 sstyle="margin:auto;"><mark>Cadastrar Cachorro</mark></h3>

        <table width="40%" height="50%" style="margin:auto;" >
            <tr>
                <td style="font-size: larger; top: 5%;">
                    <form method="POST" action="../resource/scripts/cadastrar-cachorro.php">
                       
                        <label for="ffoto">Foto (Url)</label><br>
                        <input type="text" id="ffoto" name="ffoto" value="" required><br>

                        <label for="fnome">Nome</label><br>
                        <input type="text" id="fnome" name="fnome" value="" required><br>

                        <label for="fidade">Idade</label><br>
                        <input type="number" id="fidade" name="fidade" value="" required><br>

                        <label for="fraca">Raça</label><br>
                        <input type="text" id="fraca" name="fraca" value="" required><br>

                        <label for="fsexo">Sexo</label><br>
                        <input type="text" id="fsexo" name="fsexo" value="" required><br>

                        <label for="fcor">Cor</label><br>
                        <input type="text" id="fcor" name="fcor" value="" required><br>
                        
                        <label for="fdesc">Descrição</label><br>
                        <textarea name="message" rows="10" cols="50" required></textarea> <br><br>

                        <input type="reset">   <input type="submit" value="Submit">
                     
                    </form> 
                </td>
        </table>

        <footer>
            Site desenvolvido por Victor Santos
        </footer>

    </body>
</html>