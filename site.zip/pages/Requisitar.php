<!-- HTML 4 -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- HTML5 -->
<meta charset="utf-8"/>

<!DOCTYPE html>
<html>
    
    <head>
        <title> Site em construção: Home</title>

        <link rel="stylesheet" href="../resource/css/styles.css">
    </head>

    <body>
        
        <nav id="menu-h">
            <ul>
                <li><a href="../index.php">Audopt</a></li>
                <li><a href="Adote.php">Adote</a></li>
                <li><a href="Sobre.html">Sobre</a></li>
                <li><a href="Contato.html">Contato</a></li>
            </ul>
        </nav>

        <br>

        <?php
            $nome = $_GET['dogNome']; 
            echo "<h3><mark>Quero adotar ".$nome."</mark></h3>";
        ?>
        <br>

        <table width="40%" height="100%" >
            <tr>
                <td style="font-size: larger; top: 5%;">
                    <form action="../resource/scripts/adotar-email.php" method="POST">
                       
                        <label for="fnome">Nome Completo</label><br>
                        <input type="text" id="fnome" name="fnome" value="" required><br><br>

                        <label for="femail">Email</label><br>
                        <input type="text" id="femail" name="femail" value="" required><br><br>

                        <label for="ftel">Telefone</label><br>
                        <input type="text" id="ftel" name="ftel" value="" required><br><br>

                        <label for="fend">Endereço</label><br>
                        <input type="text" id="fend" name="fend" value="" required><br><br>

                        <label for="lidade">Idade</label><br>
                        <input type="text" id="lidade" name="lidade" value="" required><br><br>

                        <label for="lalerg">Alguem na sua residencia é alergico a cachorros?</label><br>
                            <select name="optAlerg">
                                <option value='Sim'>Sim</option>
                                <option value='Não'>Não</option>
                            </select>
                        <br><br>

                        <label for="lanimais">Quanto animais você já possui?</label><br>
                        <input type="text" id="lanimais" name="lanimais" value="" required><br><br>

                        <label for="lresid">Qual tipo de residencia você vive?</label><br>
                            <select name="optResid">
                                <option value='Casa'>Casa</option>
                                <option value='Apartamento'>Apartamento</option>
                                <option value='Outro'>Outro</option>
                            </select>
                            <br><br>

                        <?php
                            echo "<label for=\"lassunto\">Por que você quer adotar ".$nome."?</label><br>";
                        ?>
                        <textarea name="message" rows="10" cols="50" required></textarea> <br><br>
                       
                        <input type="reset" value="Limpar">   
                        <input type="submit" value="Solicitar adoação">
                     
                    </form> 
                </td>
        </table>

        

        <footer>
            Site desenvolvido por Victor Santos
        </footer>

    </body>
</html>