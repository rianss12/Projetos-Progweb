<!-- HTML 4 -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- HTML5 -->
<meta charset="utf-8"/>

<?php include("../resource/scripts/connect.php"); ?>

<!DOCTYPE html>
<html>
    
    <head>
        <title> Site em construção: Home</title>

        <link rel="stylesheet" href="../resource/css/styles.css">
        <style>
            .Search-bar, .search-button{
                font-size:15px;
                padding: 5px 10px;
                position: relative;
                left:30%;
            }

            .opt{
                font-size:15px;
                padding: 2px 10px;
                position: relative;
                left:30%;
            }

            .Search-bar {
                border-radius:4px 0px 0px 4px;
                width:20em;
                text-align: left;
                border: 2px solid #EEEEEE;
                background:  #EEEEEE;
                outline: none;
            }

            .Search-bar:focus {
                border:2px solid #0485ff;
            }

            .search-button {
                border-radius:0px 4px 4px 0px;
                border:2px solid rgb(24, 139, 233) ;
                background: rgb(24, 139, 233);
                color:white;
                transition: 0.15s;
            }
        </style>
    </head>

    <body>
        
        <nav id="menu-h">
            <ul>
                <li><a href="../index.php">Audopt</a></li>
                <li><a href="Adote.php">Adote</a></li>
                <li><a href="Sobre.html">Sobre</a></li>
                <li><a href="Contato.html">Contato</a></li>
            </ul>
        </nav>

        <br>
        <form name="frmBusca" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>" >
            <input class="Search-bar" name ="busca"placeholder="Procure aqui...">
            <select class="opt" name="opt">
                <option value='raca'>Raça</option>
                <option value='cor'>Cor</option>
                <option value='sexo'>Sexo</option>
                <option value='idade'>Idade</option>
            </select>
            <input class="search-button" type="submit" value="Pesquisar" />
        </form>

        <br><br><br>

        <div class="wrapper">
            <?php
                $opcao = $_POST['opt'];
                $busca = $_POST['busca'];

                $sql = "SELECT * FROM Cachorro";

                if($opcao == 'raca'){
                    $sql = "SELECT * FROM Cachorro WHERE raca LIKE '%$busca%'";
                } else if($opcao == 'cor'){
                    $sql = "SELECT * FROM Cachorro WHERE cor LIKE '%$busca%'";
                } else if($opcao == 'sexo'){
                    $sql = "SELECT * FROM Cachorro WHERE sexo LIKE '%$busca%'";
                } else if($opcao == 'idade'){
                    $sql = "SELECT * FROM Cachorro WHERE idade=$busca";
                }

                $results = $mysqli_connection->query($sql);
                while($row = $results->fetch_assoc()){
                    $page = "./Animal.php?dogID=" .$row["id"];;
                    echo "<a href='{$page}' class=\"link\">";
                        echo "<div class=\"card\">";
                        echo " <img src=\"".$row["foto_url"]."\" alt=\"Avatar\">";
                        echo "<div class=\"info\">";
                        echo '<h4>'.$row["nome"].'</h4>';
                    echo "</div></div></a>";
                }
                echo "</tr>";
            ?>
        </div>

        <br><br><br>

        <footer>
            Site desenvolvido por Victor Santos
        </footer>

    </body>
</html>