<!-- HTML 4 -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- HTML5 -->
<meta charset="utf-8"/>

<?php include("../resource/scripts/connect.php"); ?>

<!DOCTYPE html>
<html>
    
    <head>
        <title> Audopt: Adote</title>

        <link rel="stylesheet" href="../resource/css/styles.css">

        <style>
            ul{
                list-style: none;
            }
            .pata { 
                position: relative;
                margin: 15px 10px;
                color: #43484D;
            } 
            .pata::before{
                content: '';
                position: relative;
                left: 0;
                top: 0;
                padding: 2px 14px;
                background-image: url("../images/pata.svg");
                background-repeat: no-repeat;
                background-size: cover;
                margin-right: 3px;
            }
        </style>
    </head>

    <body>
        
        <nav id="menu-h">
            <ul>
                <li><a href="../index.php">Audopt</a></li>
                <li><a href="Adote.php">Adote</a></li>
                <li><a href="Sobre.html">Sobre</a></li>
                <li><a href="Contato.html">Contato</a></li>
            </ul>
        </nav>



        <main class="container">
 
            <!-- Left Column / Dog's Image -->
            <?php  
                $id = $_GET['dogID']; 
                $results = $mysqli_connection->query("SELECT * FROM Cachorro where id=$id");

                while($row = $results->fetch_assoc()){
                    echo "  <div class=\"left-column\">
                                <img src=\"".$row["foto_url"]."\" alt=\"\">
                                <br>
                            </div>
                        
                            <div class=\"right-column\">

                                <div class=\"product-description\">
                                    <span>Adote</span>
                                    <h1>".$row["nome"]."</h1>
                                    <ul>
                                        <li class=\"pata\">Nome: ".$row["nome"]."</li>
                                        <li class=\"pata\">Idade: ".$row["idade"]."</li>
                                        <li class=\"pata\">Raça: ".$row["raca"]."</li>
                                        <li class=\"pata\">Sexo:".$row["sexo"]."</li>
                                        <li class=\"pata\">Cor: ".$row["cor"]."</li>
                                    </ul>
                                    <p>
                                        ".$row["descricao"]."
                                    </p>
                                </div>
                                <div class=\"product-price\">
                                    <a href=\"Requisitar.php?dogNome=" .$row["nome"]."\" class=\"cart-btn\">Quero adotar</a>
                                </div>
                            </div>
                            ";
                }

            ?>
          </main>
        
        <br><br>
        <footer>
            Site desenvolvido por Victor Santos
        </footer>

    </body>
</html>