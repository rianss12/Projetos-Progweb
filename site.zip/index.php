<!-- HTML 4 -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- HTML5 -->
<meta charset="utf-8"/>

<?php include("resource/scripts/connect.php"); ?>

<!DOCTYPE html>
<html>
    
    <head>
        <title> Site em construção: Home</title>

        <link rel="stylesheet" href="./resource/css/styles.css">
    </head>

    <body>
        
        <nav id="menu-h">
            <ul>
                <li><a href="index.php">Audopt</a></li>
                <li><a href="pages/Adote.php">Adote</a></li>
                <li><a href="pages/Sobre.html">Sobre</a></li>
                <li><a href="pages/Contato.html">Contato</a></li>
            </ul>
        </nav>

        <div class="header">
            <img src="./images/Audopt.png" class="folder">
        </div> 


        <h3><mark>Em destaque</mark></h3>

        <br><br>
    


        <div class="wrapper">
            <?php  
                $count = 0;
                $results = $mysqli_connection->query("SELECT * FROM Cachorro");

                while($row = $results->fetch_assoc()){
                    if($count < 3){
                        $page = "./pages/Animal.php?dogID=" .$row["id"];
                        echo "<td><a href='{$page}' class=\"link\">";
                            echo "<div class=\"card\">";
                            echo " <img src=\"".$row["foto_url"]."\" alt=\"Avatar\">";
                            echo "<div class=\"info\">";
                            echo '<h4>'.$row["nome"].'</h4>';
                        echo "</div></div></a>";
                        $count ++;
                    }else{
                        break;
                    }
                }
            ?>

        </div>

        <br><br>
        

        <footer>
            <a href="./pages/login.html">Site desenvolvido por Victor Santos</a>
        </footer>

    </body>
</html>