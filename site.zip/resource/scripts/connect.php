<?php

    $servidor = "localhost";
    $user = "victor";
    $senha = "password";
    $banco = "projeto";

    $mysqli_connection = mysqli_connect($servidor, $user, $senha, $banco);

    
    if(!$mysqli_connection){
        echo "Não obteve exito na conexão";
    }

?>