<?php
    require('connect.php');

    $user = $_POST['flogin'];
    $pwd1 =  MD5($_POST['fpwd']);
    $pwd2 =  MD5($_POST['fpwd2']);
    

    if($pwd1 == $pwd2){
        $stmt = $mysqli_connection->query("SELECT * FROM User WHERE username='$user'");

        if($stmt->num_rows != 0){
            echo "Este usuário já existe";
        }else{ 
            $stmt = $mysqli_connection->prepare("INSERT INTO User (username, senha) VALUES (?, ?)");
            $stmt->bind_param('ss', $user, $pwd1);
            $stmt->execute();
            
            if($stmt){
                echo "Usuário criado com sucesso";
            }else{
                echo "Erro: Usuário não cadastrado!";
            }
        }
    }
    else{
        echo "Usuário não cadastrado <br> Senhas diferentes!";
    }

    echo "<a href=\"../../pages/ADM-Usuarios.php\"><br>Voltar</a>";
    $mysqli_connection->close();
?>