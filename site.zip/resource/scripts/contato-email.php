<?php
    require('./email.php');

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];
    $data = date('d/m/Y H:i:s');

    $mail->Subject = $assunto;
    $mail->Body = " Nome: {$nome}<br>
                    Email: {$email}<br>
                    Mensagem: {$mensagem}<br>
                    Data/hora: {$data}";

    if($mail->send()) {
        echo 'Email enviado com sucesso.';
    } else {
        echo 'Email não enviado.';
    }

    echo "<a href=\"../../index.php\"><br>Voltar</a>";
?>