<?php
    date_default_timezone_set('America/Sao_Paulo');
    
    require_once('../../src/PHPMailer.php');
    require_once('../../src/SMTP.php');
    require_once('../../src/Exception.php');
    
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    $Meuemail = 'audopt.proj@gmail.com';
    $senha = 'audopt123';

    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $Meuemail;
    $mail->Password = $senha;
    $mail->Port = 587;

    $mail->setFrom($Meuemail);
    $mail->addAddress($Meuemail);

    $mail->isHTML(true);
?>