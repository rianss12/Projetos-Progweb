<?php
    require('./email.php');

    $nome = $_POST['fnome'];
    $email = $_POST['femail'];
    $tel = $_POST['ftel'];
    $end = $_POST['fend'];
    $idade = $_POST['lidade'];
    $alerg = $_POST['optAlerg'];
    $animais = $_POST['lanimais'];
    $resid = $_POST['optResid'];
    $mensagem = $_POST['message'];

    $dog = $_POST['ldog'];

    $data = date('d/m/Y H:i:s');

    $assunto = 'Interesse Adotar';
    
    $mail->Subject = $assunto;
    $mail->Body = " Nome: {$nome}<br>
                    Email: {$email}<br>
                    Tel: {$tel}<br>
                    Endereço: {$end}<br>
                    Idade: {$idade}<br>
                    Alergicos: {$alerg}<br>
                    Possui animais: {$animais}<br>
                    Tipo de Residencia: {$resid}<br>
                    Mensagem: {$mensagem}<br>
                    Data/hora: {$data}";

    if($mail->send()) {
        echo 'Email enviado com sucesso.';
    } else {
        echo 'Email não enviado.';
    }

    echo "<a href=\"../../index.php\"><br>Voltar</a>";
?>