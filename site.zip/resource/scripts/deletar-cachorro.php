<?php
    require('connect.php');

    $id = $_GET['dogID'];    

    $stmt = $mysqli_connection->prepare("DELETE FROM Cachorro WHERE id=?");
    $stmt->bind_param('i', $id);
  
    $stmt->execute();

    if($stmt)
        echo "Cachorro deletado com sucesso!";
     else
     echo "Erro: Cachorro não foi delatado!";

    echo "<a href=\"../../pages/ADM-Cachorros.php\"><br>Voltar</a>";
    $mysqli_connection->close();
?>