<?php
  require('connect.php');

  $myusername = $_POST['username'];
  $mypassword = $_POST['password']; 

  $sql = "SELECT * FROM User WHERE username = '$myusername' AND senha = '$mypassword'";
  $results = $mysqli_connection->query($sql);
  $row = $results->fetch_assoc();
  

    if(mysqli_num_rows($results) == 1){
        header("location: ../../pages/ADM-Usuarios.php");
    }
    else {
        $error = "Your Login Name or Password is invalid";
        header("location: ../../pages/login.html");
    }

  
  $results->free();
  $mysqli_connection->close();

?>