<?php
    require('connect.php');

    $foto = $_POST['ffoto'];
    $nome = $_POST['fnome'];
    $idade = $_POST['fidade'];
    $raca = $_POST['fraca'];
    $sexo = $_POST['fsexo'];
    $cor = $_POST['fcor'];
    $desc = $_POST['message'];
    
    $stmt = $mysqli_connection->prepare("INSERT INTO Cachorro (foto_url, nome, idade, raca, sexo, cor, descricao) VALUES ('$foto', '$nome', $idade, '$raca', '$sexo', '$cor', '$desc')");
    $stmt->execute();

    
    if($stmt){
        echo $nome." adicionado com sucesso";
    }else{
        echo "Erro: Cachorro não adicionado!";
    }

    echo "<a href=\"../../pages/ADM-Cachorros.php\"><br>Voltar</a>";
    $mysqli_connection->close();
?>