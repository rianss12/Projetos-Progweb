<?php
    require('connect.php');

    $id = $_GET['userID'];    

    $stmt = $mysqli_connection->prepare("DELETE FROM User WHERE id=?");
    $stmt->bind_param('i', $id);
  
    $stmt->execute();

    if($stmt)
        echo "Usuario deletado com sucesso!";
     else
     echo "Erro: Usuário não foi delatado!";

    echo "<a href=\"../../pages/ADM-Usuarios.php\"><br>Voltar</a>";
    $mysqli_connection->close();
?>